import request from '@/utils/request'

// 查询AI研报列表
export function listTfriskreport(query) {
  return request({
    url: '/risk/tfriskreport/list',
    method: 'get',
    params: query
  })
}

// 查询AI研报详细
export function getTfriskreport(id) {
  return request({
    url: '/risk/tfriskreport/' + id,
    method: 'get'
  })
}

// 新增AI研报
export function addTfriskreport(data) {
  return request({
    url: '/risk/tfriskreport',
    method: 'post',
    data: data
  })
}

// 修改AI研报
export function updateTfriskreport(data) {
  return request({
    url: '/risk/tfriskreport',
    method: 'put',
    data: data
  })
}

// 删除AI研报
export function delTfriskreport(id) {
  return request({
    url: '/risk/tfriskreport/' + id,
    method: 'delete'
  })
}
