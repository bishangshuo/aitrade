<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="股票代码" prop="stockCode">
        <el-input
          v-model="queryParams.stockCode"
          placeholder="请输入股票代码"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="股票名称" prop="stockName">
        <el-input
          v-model="queryParams.stockName"
          placeholder="请输入股票名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="风险公告ID" prop="riskAnnId">
        <el-input
          v-model="queryParams.riskAnnId"
          placeholder="请输入风险公告ID"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="AI复核是否通过：0-未通过，1-通过" prop="passed">
        <el-input
          v-model="queryParams.passed"
          placeholder="请输入AI复核是否通过：0-未通过，1-通过"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['risk:tfriskreport:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['risk:tfriskreport:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['risk:tfriskreport:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['risk:tfriskreport:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="tfriskreportList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="${comment}" align="center" prop="id" />
      <el-table-column label="股票代码" align="center" prop="stockCode" />
      <el-table-column label="股票名称" align="center" prop="stockName" />
      <el-table-column label="市场类型：1-A股，2-港股，3-美股" align="center" prop="marketType" />
      <el-table-column label="风险公告ID" align="center" prop="riskAnnId" />
      <el-table-column label="AI输入参数" align="center" prop="inputParams" />
      <el-table-column label="AI输出结果" align="center" prop="outputResponse" />
      <el-table-column label="AI复核是否通过：0-未通过，1-通过" align="center" prop="passed" />
      <el-table-column label="备注" align="center" prop="remarks" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['risk:tfriskreport:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['risk:tfriskreport:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改AI研报对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="100px">
        <el-row>
          <el-col :span="24">
            <el-form-item label="股票代码" prop="stockCode">
              <el-input v-model="form.stockCode" placeholder="请输入股票代码" />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="股票名称" prop="stockName">
              <el-input v-model="form.stockName" placeholder="请输入股票名称" />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="风险公告ID" prop="riskAnnId">
              <el-input v-model="form.riskAnnId" placeholder="请输入风险公告ID" />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="AI输入参数" prop="inputParams">
              <el-input v-model="form.inputParams" type="textarea" placeholder="请输入内容" />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="AI输出结果" prop="outputResponse">
              <el-input v-model="form.outputResponse" type="textarea" placeholder="请输入内容" />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="AI复核是否通过：0-未通过，1-通过" prop="passed">
              <el-input v-model="form.passed" placeholder="请输入AI复核是否通过：0-未通过，1-通过" />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="备注" prop="remarks">
              <el-input v-model="form.remarks" type="textarea" placeholder="请输入内容" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listTfriskreport, getTfriskreport, delTfriskreport, addTfriskreport, updateTfriskreport } from "@/api/risk/tfriskreport"

export default {
  name: "Tfriskreport",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // AI研报表格数据
      tfriskreportList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        stockCode: null,
        stockName: null,
        marketType: null,
        riskAnnId: null,
        inputParams: null,
        outputResponse: null,
        passed: null,
        remarks: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        stockCode: [
          { required: true, message: "股票代码不能为空", trigger: "blur" }
        ],
        stockName: [
          { required: true, message: "股票名称不能为空", trigger: "blur" }
        ],
        marketType: [
          { required: true, message: "市场类型：1-A股，2-港股，3-美股不能为空", trigger: "change" }
        ],
        riskAnnId: [
          { required: true, message: "风险公告ID不能为空", trigger: "blur" }
        ],
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    /** 查询AI研报列表 */
    getList() {
      this.loading = true
      listTfriskreport(this.queryParams).then(response => {
        this.tfriskreportList = response.rows
        this.total = response.total
        this.loading = false
      })
    },
    // 取消按钮
    cancel() {
      this.open = false
      this.reset()
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        stockCode: null,
        stockName: null,
        marketType: null,
        riskAnnId: null,
        inputParams: null,
        outputResponse: null,
        passed: null,
        remarks: null,
        createTime: null
      }
      this.resetForm("form")
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1
      this.getList()
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm")
      this.handleQuery()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length !== 1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset()
      this.open = true
      this.title = "添加AI研报"
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset()
      const id = row.id || this.ids
      getTfriskreport(id).then(response => {
        this.form = response.data
        this.open = true
        this.title = "修改AI研报"
      })
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateTfriskreport(this.form).then(response => {
              this.$modal.msgSuccess("修改成功")
              this.open = false
              this.getList()
            })
          } else {
            addTfriskreport(this.form).then(response => {
              this.$modal.msgSuccess("新增成功")
              this.open = false
              this.getList()
            })
          }
        }
      })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids
      this.$modal.confirm('是否确认删除AI研报编号为"' + ids + '"的数据项？').then(function() {
        return delTfriskreport(ids)
      }).then(() => {
        this.getList()
        this.$modal.msgSuccess("删除成功")
      }).catch(() => {})
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('risk/tfriskreport/export', {
        ...this.queryParams
      }, `tfriskreport_${new Date().getTime()}.xlsx`)
    }
  }
}
</script>
