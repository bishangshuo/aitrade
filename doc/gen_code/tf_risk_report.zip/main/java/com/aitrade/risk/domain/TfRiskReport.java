package com.aitrade.risk.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.aitrade.common.annotation.Excel;

/**
 * AI研报对象 tf_risk_report
 * 
 * @author aitrade
 * @date 2026-10-27
 */
public class TfRiskReport extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 股票代码 */
    @Excel(name = "股票代码")
    private String stockCode;

    /** 股票名称 */
    @Excel(name = "股票名称")
    private String stockName;

    /** 市场类型：1-A股，2-港股，3-美股 */
    @Excel(name = "市场类型：1-A股，2-港股，3-美股")
    private Integer marketType;

    /** 风险公告ID */
    @Excel(name = "风险公告ID")
    private Long riskAnnId;

    /** AI输入参数 */
    @Excel(name = "AI输入参数")
    private String inputParams;

    /** AI输出结果 */
    @Excel(name = "AI输出结果")
    private String outputResponse;

    /** AI复核是否通过：0-未通过，1-通过 */
    @Excel(name = "AI复核是否通过：0-未通过，1-通过")
    private Integer passed;

    /** 备注 */
    @Excel(name = "备注")
    private String remarks;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public void setStockCode(String stockCode) 
    {
        this.stockCode = stockCode;
    }

    public String getStockCode() 
    {
        return stockCode;
    }

    public void setStockName(String stockName) 
    {
        this.stockName = stockName;
    }

    public String getStockName() 
    {
        return stockName;
    }

    public void setMarketType(Integer marketType) 
    {
        this.marketType = marketType;
    }

    public Integer getMarketType() 
    {
        return marketType;
    }

    public void setRiskAnnId(Long riskAnnId) 
    {
        this.riskAnnId = riskAnnId;
    }

    public Long getRiskAnnId() 
    {
        return riskAnnId;
    }

    public void setInputParams(String inputParams) 
    {
        this.inputParams = inputParams;
    }

    public String getInputParams() 
    {
        return inputParams;
    }

    public void setOutputResponse(String outputResponse) 
    {
        this.outputResponse = outputResponse;
    }

    public String getOutputResponse() 
    {
        return outputResponse;
    }

    public void setPassed(Integer passed) 
    {
        this.passed = passed;
    }

    public Integer getPassed() 
    {
        return passed;
    }

    public void setRemarks(String remarks) 
    {
        this.remarks = remarks;
    }

    public String getRemarks() 
    {
        return remarks;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("stockCode", getStockCode())
            .append("stockName", getStockName())
            .append("marketType", getMarketType())
            .append("riskAnnId", getRiskAnnId())
            .append("inputParams", getInputParams())
            .append("outputResponse", getOutputResponse())
            .append("passed", getPassed())
            .append("remarks", getRemarks())
            .append("createTime", getCreateTime())
            .toString();
    }
}
