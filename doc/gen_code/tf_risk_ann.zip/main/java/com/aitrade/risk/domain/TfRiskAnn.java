package com.aitrade.risk.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.aitrade.common.annotation.Excel;

/**
 * 风险公告对象 tf_risk_ann
 * 
 * @author aitrade
 * @date 2026-10-27
 */
public class TfRiskAnn extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 发布时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "发布时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date publishTime;

    /** 股票代号 */
    @Excel(name = "股票代号")
    private String stockCode;

    /** 股票名称 */
    @Excel(name = "股票名称")
    private String stockName;

    /** 市场代码 */
    @Excel(name = "市场代码")
    private String marketCode;

    /** 公告类型 */
    @Excel(name = "公告类型")
    private String annType;

    /** 消息类型 */
    @Excel(name = "消息类型")
    private String sourceType;

    /** 文章编码 */
    @Excel(name = "文章编码")
    private String artCode;

    /** 公告标题 */
    @Excel(name = "公告标题")
    private String title;

    /** 公告内容 */
    @Excel(name = "公告内容")
    private String content;

    /** 公告文件url */
    @Excel(name = "公告文件url")
    private String fileUrl;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public void setPublishTime(Date publishTime) 
    {
        this.publishTime = publishTime;
    }

    public Date getPublishTime() 
    {
        return publishTime;
    }

    public void setStockCode(String stockCode) 
    {
        this.stockCode = stockCode;
    }

    public String getStockCode() 
    {
        return stockCode;
    }

    public void setStockName(String stockName) 
    {
        this.stockName = stockName;
    }

    public String getStockName() 
    {
        return stockName;
    }

    public void setMarketCode(String marketCode) 
    {
        this.marketCode = marketCode;
    }

    public String getMarketCode() 
    {
        return marketCode;
    }

    public void setAnnType(String annType) 
    {
        this.annType = annType;
    }

    public String getAnnType() 
    {
        return annType;
    }

    public void setSourceType(String sourceType) 
    {
        this.sourceType = sourceType;
    }

    public String getSourceType() 
    {
        return sourceType;
    }

    public void setArtCode(String artCode) 
    {
        this.artCode = artCode;
    }

    public String getArtCode() 
    {
        return artCode;
    }

    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getTitle() 
    {
        return title;
    }

    public void setContent(String content) 
    {
        this.content = content;
    }

    public String getContent() 
    {
        return content;
    }

    public void setFileUrl(String fileUrl) 
    {
        this.fileUrl = fileUrl;
    }

    public String getFileUrl() 
    {
        return fileUrl;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("publishTime", getPublishTime())
            .append("stockCode", getStockCode())
            .append("stockName", getStockName())
            .append("marketCode", getMarketCode())
            .append("annType", getAnnType())
            .append("sourceType", getSourceType())
            .append("artCode", getArtCode())
            .append("title", getTitle())
            .append("content", getContent())
            .append("fileUrl", getFileUrl())
            .append("createTime", getCreateTime())
            .toString();
    }
}
