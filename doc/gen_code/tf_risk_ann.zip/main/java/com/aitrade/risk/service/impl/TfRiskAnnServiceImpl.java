package com.aitrade.risk.service.impl;

import java.util.List;
import com.aitrade.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.aitrade.risk.mapper.TfRiskAnnMapper;
import com.aitrade.risk.domain.TfRiskAnn;
import com.aitrade.risk.service.ITfRiskAnnService;

/**
 * 风险公告Service业务层处理
 * 
 * @author aitrade
 * @date 2026-10-27
 */
@Service
public class TfRiskAnnServiceImpl implements ITfRiskAnnService 
{
    @Autowired
    private TfRiskAnnMapper tfRiskAnnMapper;

    /**
     * 查询风险公告
     * 
     * @param id 风险公告主键
     * @return 风险公告
     */
    @Override
    public TfRiskAnn selectTfRiskAnnById(Long id)
    {
        return tfRiskAnnMapper.selectTfRiskAnnById(id);
    }

    /**
     * 查询风险公告列表
     * 
     * @param tfRiskAnn 风险公告
     * @return 风险公告
     */
    @Override
    public List<TfRiskAnn> selectTfRiskAnnList(TfRiskAnn tfRiskAnn)
    {
        return tfRiskAnnMapper.selectTfRiskAnnList(tfRiskAnn);
    }

    /**
     * 新增风险公告
     * 
     * @param tfRiskAnn 风险公告
     * @return 结果
     */
    @Override
    public int insertTfRiskAnn(TfRiskAnn tfRiskAnn)
    {
        tfRiskAnn.setCreateTime(DateUtils.getNowDate());
        return tfRiskAnnMapper.insertTfRiskAnn(tfRiskAnn);
    }

    /**
     * 修改风险公告
     * 
     * @param tfRiskAnn 风险公告
     * @return 结果
     */
    @Override
    public int updateTfRiskAnn(TfRiskAnn tfRiskAnn)
    {
        return tfRiskAnnMapper.updateTfRiskAnn(tfRiskAnn);
    }

    /**
     * 批量删除风险公告
     * 
     * @param ids 需要删除的风险公告主键
     * @return 结果
     */
    @Override
    public int deleteTfRiskAnnByIds(Long[] ids)
    {
        return tfRiskAnnMapper.deleteTfRiskAnnByIds(ids);
    }

    /**
     * 删除风险公告信息
     * 
     * @param id 风险公告主键
     * @return 结果
     */
    @Override
    public int deleteTfRiskAnnById(Long id)
    {
        return tfRiskAnnMapper.deleteTfRiskAnnById(id);
    }
}
