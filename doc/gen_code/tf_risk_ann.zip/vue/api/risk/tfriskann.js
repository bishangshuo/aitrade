import request from '@/utils/request'

// 查询风险公告列表
export function listTfriskann(query) {
  return request({
    url: '/risk/tfriskann/list',
    method: 'get',
    params: query
  })
}

// 查询风险公告详细
export function getTfriskann(id) {
  return request({
    url: '/risk/tfriskann/' + id,
    method: 'get'
  })
}

// 新增风险公告
export function addTfriskann(data) {
  return request({
    url: '/risk/tfriskann',
    method: 'post',
    data: data
  })
}

// 修改风险公告
export function updateTfriskann(data) {
  return request({
    url: '/risk/tfriskann',
    method: 'put',
    data: data
  })
}

// 删除风险公告
export function delTfriskann(id) {
  return request({
    url: '/risk/tfriskann/' + id,
    method: 'delete'
  })
}
