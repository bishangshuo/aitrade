import request from '@/utils/request'

// 查询研报公告列表
export function listTfriskreportann(query) {
  return request({
    url: '/risk/tfriskreportann/list',
    method: 'get',
    params: query
  })
}

// 查询研报公告详细
export function getTfriskreportann(id) {
  return request({
    url: '/risk/tfriskreportann/' + id,
    method: 'get'
  })
}

// 新增研报公告
export function addTfriskreportann(data) {
  return request({
    url: '/risk/tfriskreportann',
    method: 'post',
    data: data
  })
}

// 修改研报公告
export function updateTfriskreportann(data) {
  return request({
    url: '/risk/tfriskreportann',
    method: 'put',
    data: data
  })
}

// 删除研报公告
export function delTfriskreportann(id) {
  return request({
    url: '/risk/tfriskreportann/' + id,
    method: 'delete'
  })
}
