package com.aitrade.risk.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.aitrade.common.annotation.Excel;

/**
 * 研报公告对象 tf_risk_report_ann
 * 
 * @author aitrade
 * @date 2026-10-27
 */
public class TfRiskReportAnn extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 风险研报ID */
    @Excel(name = "风险研报ID")
    private Long riskReportId;

    /** 风险公告ID */
    @Excel(name = "风险公告ID")
    private Long riskAnnId;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public void setRiskReportId(Long riskReportId) 
    {
        this.riskReportId = riskReportId;
    }

    public Long getRiskReportId() 
    {
        return riskReportId;
    }

    public void setRiskAnnId(Long riskAnnId) 
    {
        this.riskAnnId = riskAnnId;
    }

    public Long getRiskAnnId() 
    {
        return riskAnnId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("riskReportId", getRiskReportId())
            .append("riskAnnId", getRiskAnnId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
