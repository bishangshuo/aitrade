package com.aitrade.stock.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.aitrade.stock.mapper.TaCalMapper;
import com.aitrade.stock.domain.TaCal;
import com.aitrade.stock.service.ITaCalService;

/**
 * 交易日历Service业务层处理
 * 
 * @author bishangshuo
 * @date 2026-10-25
 */
@Service
public class TaCalServiceImpl implements ITaCalService 
{
    @Autowired
    private TaCalMapper taCalMapper;

    /**
     * 查询交易日历
     * 
     * @param id 交易日历主键
     * @return 交易日历
     */
    @Override
    public TaCal selectTaCalById(Long id)
    {
        return taCalMapper.selectTaCalById(id);
    }

    /**
     * 查询交易日历列表
     * 
     * @param taCal 交易日历
     * @return 交易日历
     */
    @Override
    public List<TaCal> selectTaCalList(TaCal taCal)
    {
        return taCalMapper.selectTaCalList(taCal);
    }

    /**
     * 新增交易日历
     * 
     * @param taCal 交易日历
     * @return 结果
     */
    @Override
    public int insertTaCal(TaCal taCal)
    {
        return taCalMapper.insertTaCal(taCal);
    }

    /**
     * 修改交易日历
     * 
     * @param taCal 交易日历
     * @return 结果
     */
    @Override
    public int updateTaCal(TaCal taCal)
    {
        return taCalMapper.updateTaCal(taCal);
    }

    /**
     * 批量删除交易日历
     * 
     * @param ids 需要删除的交易日历主键
     * @return 结果
     */
    @Override
    public int deleteTaCalByIds(Long[] ids)
    {
        return taCalMapper.deleteTaCalByIds(ids);
    }

    /**
     * 删除交易日历信息
     * 
     * @param id 交易日历主键
     * @return 结果
     */
    @Override
    public int deleteTaCalById(Long id)
    {
        return taCalMapper.deleteTaCalById(id);
    }
}
