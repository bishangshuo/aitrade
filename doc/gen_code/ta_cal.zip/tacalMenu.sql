-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('交易日历', '1068', '1', 'tacal', 'stock/tacal/index', 1, 0, 'C', '0', '0', 'stock:tacal:list', '#', 'admin', sysdate(), '', null, '交易日历菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('交易日历查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'stock:tacal:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('交易日历新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'stock:tacal:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('交易日历修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'stock:tacal:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('交易日历删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'stock:tacal:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('交易日历导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'stock:tacal:export',       '#', 'admin', sysdate(), '', null, '');