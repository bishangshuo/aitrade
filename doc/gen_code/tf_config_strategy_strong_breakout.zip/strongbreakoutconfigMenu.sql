-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('主升浪策略回测参数配置', '1106', '1', 'strongbreakoutconfig', 'stock/strongbreakoutconfig/index', 1, 0, 'C', '0', '0', 'stock:strongbreakoutconfig:list', '#', 'admin', sysdate(), '', null, '主升浪策略回测参数配置菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('主升浪策略回测参数配置查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'stock:strongbreakoutconfig:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('主升浪策略回测参数配置新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'stock:strongbreakoutconfig:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('主升浪策略回测参数配置修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'stock:strongbreakoutconfig:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('主升浪策略回测参数配置删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'stock:strongbreakoutconfig:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('主升浪策略回测参数配置导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'stock:strongbreakoutconfig:export',       '#', 'admin', sysdate(), '', null, '');