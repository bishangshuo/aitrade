-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('任务规划', '1068', '1', 'tatask', 'stock/tatask/index', 1, 0, 'C', '0', '0', 'stock:tatask:list', '#', 'admin', sysdate(), '', null, '任务规划菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('任务规划查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'stock:tatask:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('任务规划新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'stock:tatask:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('任务规划修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'stock:tatask:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('任务规划删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'stock:tatask:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('任务规划导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'stock:tatask:export',       '#', 'admin', sysdate(), '', null, '');