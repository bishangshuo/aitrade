-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('超跌反弹策略回测参数配置', '1106', '1', 'oversoldreboundconfig', 'stock/oversoldreboundconfig/index', 1, 0, 'C', '0', '0', 'stock:oversoldreboundconfig:list', '#', 'admin', sysdate(), '', null, '超跌反弹策略回测参数配置菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('超跌反弹策略回测参数配置查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'stock:oversoldreboundconfig:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('超跌反弹策略回测参数配置新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'stock:oversoldreboundconfig:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('超跌反弹策略回测参数配置修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'stock:oversoldreboundconfig:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('超跌反弹策略回测参数配置删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'stock:oversoldreboundconfig:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('超跌反弹策略回测参数配置导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'stock:oversoldreboundconfig:export',       '#', 'admin', sysdate(), '', null, '');