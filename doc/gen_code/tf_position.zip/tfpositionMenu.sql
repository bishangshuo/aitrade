-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測當前持倉', '1068', '1', 'tfposition', 'stock/tfposition/index', 1, 0, 'C', '0', '0', 'stock:tfposition:list', '#', 'admin', sysdate(), '', null, '回測當前持倉菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測當前持倉查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'stock:tfposition:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測當前持倉新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'stock:tfposition:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測當前持倉修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'stock:tfposition:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測當前持倉删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'stock:tfposition:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測當前持倉导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'stock:tfposition:export',       '#', 'admin', sysdate(), '', null, '');