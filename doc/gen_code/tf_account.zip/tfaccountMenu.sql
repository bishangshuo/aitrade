-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測虛擬賬戶', '1068', '1', 'tfaccount', 'tfstock/tfaccount/index', 1, 0, 'C', '0', '0', 'tfstock:tfaccount:list', '#', 'admin', sysdate(), '', null, '回測虛擬賬戶菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測虛擬賬戶查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'tfstock:tfaccount:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測虛擬賬戶新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'tfstock:tfaccount:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測虛擬賬戶修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'tfstock:tfaccount:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測虛擬賬戶删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'tfstock:tfaccount:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測虛擬賬戶导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'tfstock:tfaccount:export',       '#', 'admin', sysdate(), '', null, '');