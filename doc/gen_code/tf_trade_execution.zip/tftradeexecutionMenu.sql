-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測歷史成交交割單', '1068', '1', 'tftradeexecution', 'stock/tftradeexecution/index', 1, 0, 'C', '0', '0', 'stock:tftradeexecution:list', '#', 'admin', sysdate(), '', null, '回測歷史成交交割單菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測歷史成交交割單查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'stock:tftradeexecution:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測歷史成交交割單新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'stock:tftradeexecution:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測歷史成交交割單修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'stock:tftradeexecution:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測歷史成交交割單删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'stock:tftradeexecution:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測歷史成交交割單导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'stock:tftradeexecution:export',       '#', 'admin', sysdate(), '', null, '');