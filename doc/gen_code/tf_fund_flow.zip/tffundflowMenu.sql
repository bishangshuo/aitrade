-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測資金流水明細', '1068', '1', 'tffundflow', 'stock/tffundflow/index', 1, 0, 'C', '0', '0', 'stock:tffundflow:list', '#', 'admin', sysdate(), '', null, '回測資金流水明細菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測資金流水明細查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'stock:tffundflow:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測資金流水明細新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'stock:tffundflow:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測資金流水明細修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'stock:tffundflow:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測資金流水明細删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'stock:tffundflow:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('回測資金流水明細导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'stock:tffundflow:export',       '#', 'admin', sysdate(), '', null, '');